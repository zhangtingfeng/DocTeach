<?php
return array(
    // 应用版本
    'app_version' => '3.2.2',
    
    // 发布时间
    'release_time' => '20221116',

    // 修订版本
    'revise_version' => '1'

);
