<?php
namespace app\home\model;

use core\basic\Model;

class ContributionModel extends Model{
//具体数据库操作方法请自行处理
}